# Ethical Hacking Academy - React SPA

## Setup
1. Install dependencies:
   ```bash
   npm install
   ```

2. Run locally:
   ```bash
   npm run dev
   ```

3. Build for production:
   ```bash
   npm run build
   ```

4. Deploy on Netlify:
   - Go to https://app.netlify.com/
   - Create a new site, choose **Deploy manually**
   - Build locally (`npm run build`), then drag & drop the `dist` folder into Netlify.
   - Or connect GitHub repo and let Netlify build automatically.

**Note:** The `_redirects` file ensures React Router works on Netlify.
